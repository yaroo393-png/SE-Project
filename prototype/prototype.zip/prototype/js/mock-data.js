/*
 * mock-data.js — ข้อมูลจำลองสำหรับ prototype (ไม่มี server/DB)
 * ชื่อยาเป็น "ยาตัวอย่าง" ทั้งหมด ไม่ใช่คำแนะนำทางการแพทย์
 */
(function (root) {
  'use strict';
  root.MedMind = root.MedMind || {};

  /** ตัวอย่างผลอ่านฉลาก (OCR จำลอง) — ครอบคลุม AC ทุกข้อของ FR-02 */
  var samples = [
    {
      id: 'clear-after',
      title: 'ฉลากชัด: หลังอาหารเช้า',
      hint: 'FR-02 ✓1 ✓2 ✓6',
      ocr: { name: 'ยาตัวอย่าง A 500 มก.', pills: 1, relation: 'after', slot: 'morning', caution: 'รับประทานพร้อมน้ำเปล่า', contraindication: 'ห้ามใช้ถ้าเคยแพ้ยานี้' }
    },
    {
      id: 'before-30',
      title: 'ฉลากชัด: ก่อนอาหารเช้า 30 นาที',
      hint: 'FR-02 ✓8 → เตือน 06:30 ถ้าเช้า 07:00',
      ocr: { name: 'ยาตัวอย่าง B 10 มก.', pills: 2, relation: 'before', slot: 'morning', minutesBefore: 30, caution: 'ห้ามเคี้ยวเม็ดยา', contraindication: '' }
    },
    {
      id: 'bedtime',
      title: 'ฉลากชัด: ก่อนนอน',
      hint: 'FR-02 ✓9 → เตือนตามเวลาเข้านอน',
      ocr: { name: 'ยาตัวอย่าง C 5 มก.', pills: 1, relation: 'bedtime', caution: '', contraindication: 'ห้ามขับรถหลังรับประทาน' }
    },
    {
      id: 'unclear-fields',
      title: 'ฉลากเลอะ: อ่านชื่อยากับจำนวนเม็ดไม่ได้',
      hint: 'FR-02 ✗3 → "กรุณาตรวจสอบ" บันทึกไม่ได้จนครบ',
      ocr: { name: null, pills: null, relation: 'after', slot: 'noon', caution: 'รับประทานหลังอาหารทันที', contraindication: null }
    },
    {
      id: 'before-no-minutes',
      title: 'ฉลาก "ก่อนอาหารเย็น" ไม่ระบุจำนวนนาที',
      hint: 'FR-02 ✗10 → ช่องนาทีว่าง ระบบไม่เดา',
      ocr: { name: 'ยาตัวอย่าง D 20 มก.', pills: 1, relation: 'before', slot: 'evening', minutesBefore: null, caution: '', contraindication: '' }
    },
    {
      id: 'prn',
      title: 'ฉลากยาที่กินเมื่อมีอาการ',
      hint: 'FR-02 ✗4 → ระบบยังไม่รองรับ',
      ocr: { name: 'ยาตัวอย่าง E (เมื่อมีอาการปวด)', pills: 1, relation: null, slot: null, prn: true }
    },
    {
      id: 'scan-failed',
      title: 'สแกนล้มเหลว (รูปมืด/เบลอ)',
      hint: 'FR-02 ✗5 → เปิดฟอร์มว่างให้กรอกเอง',
      ocr: { failed: true }
    }
  ];

  function dose(id, name, pills, timing, caution, contra) {
    return { id: id, name: name, pills: pills, caution: caution || '', contraindication: contra || '', timing: timing };
  }

  /** ชุดข้อมูลตัวอย่างสำหรับข้ามไปทดสอบรอบเตือนโดยไม่ต้องเพิ่มยาเอง */
  var scenarios = {
    basic: {
      title: 'ตัวอย่าง: จับคู่แล้ว + ยา 3 มื้อ (08:00 / 12:00 / 18:00)',
      startTime: '07:55',
      settings: { morning: '08:00', noon: '12:00', evening: '18:00', bedtime: '21:00' },
      meds: [
        dose('d1', 'ยาตัวอย่าง A 500 มก.', 1, { type: 'after', slot: 'morning' }, 'รับประทานพร้อมน้ำเปล่า', 'ห้ามใช้ถ้าเคยแพ้ยานี้'),
        dose('d2', 'ยาตัวอย่าง F 25 มก.', 2, { type: 'after', slot: 'morning' }, 'ห้ามเคี้ยวเม็ดยา', ''),
        dose('d3', 'ยาตัวอย่าง G 100 มก.', 1, { type: 'after', slot: 'noon' }, '', 'ห้ามดื่มแอลกอฮอล์'),
        dose('d4', 'ยาตัวอย่าง D 20 มก.', 1, { type: 'after', slot: 'evening' }, '', '')
      ]
    },
    overlap: {
      title: 'ตัวอย่าง: มื้อเวลาซ้อนกัน 06:45 + 07:00 (BR-16)',
      startTime: '06:40',
      settings: { morning: '07:00', noon: '12:00', evening: '18:00', bedtime: '21:00' },
      meds: [
        dose('d1', 'ยาตัวอย่าง B 10 มก.', 1, { type: 'before', slot: 'morning', minutesBefore: 15 }, 'รับประทานก่อนอาหาร', ''),
        dose('d2', 'ยาตัวอย่าง A 500 มก.', 1, { type: 'after', slot: 'morning' }, 'รับประทานพร้อมน้ำเปล่า', 'ห้ามใช้ถ้าเคยแพ้ยานี้'),
        dose('d3', 'ยาตัวอย่าง G 100 มก.', 1, { type: 'after', slot: 'noon' }, '', '')
      ]
    }
  };

  root.MedMind.mock = {
    samples: samples,
    scenarios: scenarios,
    defaultMealTimes: { morning: '07:00', noon: '12:00', evening: '18:00', bedtime: '21:00' }
  };
})(typeof self !== 'undefined' ? self : this);

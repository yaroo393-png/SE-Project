/*
 * app.js — หน้าจอของ prototype (ต่อ "ตรรกะ" ใน js/logic/ เข้ากับ DOM)
 * ไม่มี server/DB: สถานะทั้งหมดอยู่ในตัวแปร S ในหน้านี้ (รีเฟรช = เริ่มใหม่)
 * เวลาเป็นนาทีนับจากเที่ยงคืน จำลองด้วยตัวควบคุมด้านบน (ไม่ใช้นาฬิกาจริง)
 */
(function () {
  'use strict';

  var M = window.MedMind;
  var R = M.reminder;
  var C = M.confirm;
  var P = M.pairing;
  var L = M.label;
  var MOCK = M.mock;
  var t = R.parseTime;
  var fmt = R.formatTime;

  var SENIOR_ID = 'senior1';
  var CG_ID = 'cg1';
  var CG2_ID = 'cg2';

  var S; // สถานะทั้งแอป
  var doseSeq = 0;
  var notifSeq = 0;
  var audioCtx = null;
  var toastTimer = null;

  /* ====================== ตัวช่วย ====================== */

  function esc(v) {
    return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function byId(list, id) {
    for (var i = 0; i < list.length; i++) if (list[i].id === id) return list[i];
    return null;
  }

  function fresh(startTime) {
    var now = t(startTime || '06:00');
    return {
      now: now,
      ps: P.create(SENIOR_ID, now),
      meds: [],
      settings: null, // เวลามื้อ (BR-06) — ตั้งครั้งแรกตอนเพิ่มยา
      confirmState: {},
      notifications: [],
      log: [],
      reminderIds: [], // มื้อที่แสดงบนหน้าเตือนของ Senior
      dialog: null, // 'senior' | 'caregiver' = กล่องยืนยันยกเลิกจับคู่
      cg: { tab: 'status', codeInput: '', pairError: '', add: null, seen: 0 },
      gotoValue: '',
      mute: S ? S.mute : false
    };
  }

  function getMeals() {
    return S.settings ? R.buildMeals(S.meds, S.settings).meals : [];
  }

  function addLog(text) {
    S.log.unshift(fmt(S.now) + '  ' + text);
    if (S.log.length > 80) S.log.pop();
  }

  function toast(msg, bad) {
    var el = document.getElementById('toast');
    el.textContent = msg;
    el.className = 'toast show' + (bad ? ' bad' : '');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { el.className = 'toast'; }, 3600);
  }

  /** BR-09: เสียงเตือน — เบราว์เซอร์เล่นเสียงได้หลังผู้ใช้แตะหน้าเว็บอย่างน้อย 1 ครั้ง (§2.2) */
  function beep() {
    if (S.mute) return;
    try {
      var AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      if (!audioCtx) audioCtx = new AC();
      if (audioCtx.state === 'suspended') audioCtx.resume();
      [0, 0.35, 0.7].forEach(function (d) {
        var o = audioCtx.createOscillator();
        var g = audioCtx.createGain();
        o.frequency.value = 880;
        g.gain.value = 0.15;
        o.connect(g);
        g.connect(audioCtx.destination);
        o.start(audioCtx.currentTime + d);
        o.stop(audioCtx.currentTime + d + 0.2);
      });
    } catch (e) { /* ไม่มีเสียงก็ไม่เป็นไร */ }
  }

  /* ====================== เดินเวลา (จำลอง) ====================== */

  function handleEvents(events) {
    events.forEach(function (e) {
      if (!P.canView(S.ps, CG_ID, SENIOR_ID)) return; // NFR-04
      S.notifications.unshift({ id: ++notifSeq, at: e.at, kind: e.kind, late: !!e.late, text: e.text, mealId: e.mealId });
      addLog('แจ้ง Caregiver: ' + e.text);
    });
  }

  function stepMinute() {
    var meals = getMeals();
    var due = R.dueReminders(meals, S.confirmState, S.now, S.now - 1);
    if (due.sound) {
      S.reminderIds = due.display.map(function (m) { return m.id; });
      var rounds = due.firing.map(function (f) { return f.meal.label + ' รอบ ' + f.round; }).join(', ');
      addLog('🔔 เตือน + เสียงครั้งเดียว (' + rounds + ') · แสดง ' + due.display.length + ' มื้อ');
      beep();
    } else {
      // มื้อที่พ้น T+15 แล้วออกจากหน้าเตือน (ไปยืนยันช้าจากหน้าแรก — BR-15)
      S.reminderIds = S.reminderIds.filter(function (id) {
        var m = byId(meals, id);
        return m && !R.isConfirmed(S.confirmState, m) && S.now < m.time + R.EXPIRE_OFFSET;
      });
    }
    handleEvents(C.tick(S.confirmState, meals, S.now));
  }

  function advanceTo(target) {
    target = Math.min(target, 23 * 60 + 59);
    if (target <= S.now) return false;
    while (S.now < target) {
      S.now++;
      stepMinute();
    }
    return true;
  }

  /** เวลาเหตุการณ์ถัดไปที่น่าสนใจ: T, T+5, T+10, T+15 ของแต่ละมื้อ + เวลาที่ช่วงยืนยันช้าปิด */
  function nextEventTime() {
    var meals = getMeals();
    var best = null;
    meals.forEach(function (m) {
      var cands = R.ROUND_OFFSETS.map(function (o) { return m.time + o; });
      cands.push(m.time + R.EXPIRE_OFFSET);
      var end = R.lateWindowEnd(m, meals);
      if (end < R.END_OF_DAY) cands.push(end);
      cands.forEach(function (c) {
        if (c > S.now && (best === null || c < best)) best = c;
      });
    });
    return best;
  }

  /* ====================== QR จำลอง ====================== */

  function qrSvg(code) {
    var n = 25;
    var seed = 0;
    for (var i = 0; i < code.length; i++) seed = (seed * 31 + code.charCodeAt(i)) >>> 0;
    function rnd() {
      seed = (seed * 1664525 + 1013904223) >>> 0;
      return seed / 4294967296;
    }
    function finder(x, y) {
      return x < 7 && y < 7 ? (x === 0 || y === 0 || x === 6 || y === 6 || (x >= 2 && x <= 4 && y >= 2 && y <= 4)) : null;
    }
    var rects = '';
    for (var y = 0; y < n; y++) {
      for (var x = 0; x < n; x++) {
        var on;
        var f = finder(x, y);
        if (f === null) f = x >= n - 7 ? finder(n - 1 - x, y) : null;
        if (f === null) f = y >= n - 7 && x < 7 ? finder(x, n - 1 - y) : null;
        if (f !== null) on = f;
        else if ((x < 8 && y < 8) || (x >= n - 8 && y < 8) || (x < 8 && y >= n - 8)) on = false;
        else on = rnd() > 0.52;
        if (on) rects += '<rect x="' + x + '" y="' + y + '" width="1" height="1"/>';
      }
    }
    return '<svg viewBox="0 0 ' + n + ' ' + n + '" role="img" aria-label="QR จำลอง รหัส ' + esc(code) + '" shape-rendering="crispEdges"><g fill="#000">' + rects + '</g></svg>';
  }

  /* ====================== ตัวควบคุมจำลอง ====================== */

  function renderSim() {
    var next = nextEventTime();
    var gv = S.gotoValue || fmt(Math.min(S.now + 1, 1439));
    document.getElementById('sim').innerHTML =
      '<span class="sim-title">⚙️ ตัวจำลอง (ไม่ใช่หน้าจอของแอป)</span>' +
      '<span class="clock" id="clock" aria-label="เวลาจำลอง">' + fmt(S.now) + '</span>' +
      '<span class="group"><span class="group-label">เดินเวลา:</span>' +
      '<button class="sbtn" data-act="step" data-n="1">+1 นาที</button>' +
      '<button class="sbtn" data-act="step" data-n="5">+5 นาที</button>' +
      '<button class="sbtn" data-act="step" data-n="15">+15 นาที</button>' +
      '<button class="sbtn primary" data-act="next"' + (next === null ? ' disabled' : '') + '>ไปเหตุการณ์ถัดไป' + (next === null ? '' : ' (' + fmt(next) + ')') + '</button></span>' +
      '<span class="group"><span class="group-label">ไปที่เวลา:</span>' +
      '<input type="time" id="gotoTime" data-field-goto value="' + esc(gv) + '" aria-label="เวลาที่ต้องการไป">' +
      '<button class="sbtn" data-act="goto">ไป</button></span>' +
      '<span class="group"><span class="group-label">ชุดข้อมูล:</span>' +
      '<button class="sbtn" data-act="scenario" data-name="empty">เริ่มใหม่ (ยังไม่จับคู่)</button>' +
      '<button class="sbtn" data-act="scenario" data-name="basic">ตัวอย่าง: 3 มื้อ</button>' +
      '<button class="sbtn" data-act="scenario" data-name="overlap">ตัวอย่าง: มื้อซ้อนกัน</button>' +
      '<button class="sbtn" data-act="cg2">ผู้ดูแลคนที่ 2 ลองจับคู่</button></span>' +
      '<label class="chk"><input type="checkbox" data-act="mute"' + (S.mute ? ' checked' : '') + '> ปิดเสียง</label>' +
      '<span class="sim-note">เวลาเดินหน้าได้อย่างเดียว (ย้อนกลับ = กด "เริ่มใหม่") · เสียงเตือนเล่นได้หลังแตะหน้าเว็บครั้งแรก (ข้อจำกัดเบราว์เซอร์)</span>';
  }

  function renderLog() {
    var items = S.log.length
      ? S.log.map(function (l) { return '<li>' + esc(l) + '</li>'; }).join('')
      : '<li>ยังไม่มีเหตุการณ์ — กด "ไปเหตุการณ์ถัดไป" ด้านบนเพื่อเดินเวลา</li>';
    document.getElementById('log').innerHTML = '<h3>บันทึกเหตุการณ์ (ใหม่สุดอยู่บน)</h3><ol reversed>' + items + '</ol>';
  }

  /* ====================== หน้าจอ Senior ====================== */

  function cover(text) {
    return '<div class="cover">Covers: ' + esc(text) + '</div>';
  }

  function seniorPairing() {
    var ps = S.ps;
    var left = P.codeMinutesLeft(ps, S.now);
    var body =
      '<h1>เชื่อมต่อกับลูกหลาน</h1>' +
      '<p class="muted">ให้ลูกหลานสแกน QR นี้ หรือใส่รหัส 6 หลักในมือถือของเขา · ไม่ต้องสมัครบัญชี ไม่ต้องพิมพ์อะไร</p>' +
      '<div class="qrbox">' + qrSvg(ps.code) + '<div class="muted small">QR จำลอง</div></div>' +
      '<div class="code" aria-label="รหัสเชิญ">' + esc(ps.code) + '</div>' +
      '<p class="muted" style="text-align:center">' + (left > 0 ? 'ใช้ได้อีก ' + left + ' นาที · ใช้ได้ 1 ครั้ง' : '⚠ รหัสหมดอายุแล้ว กด "สร้างรหัสใหม่"') + '</p>';
    if (!ps.consent) {
      body +=
        '<div class="card warn"><strong>ก่อนเชื่อมต่อ:</strong> ฉันยินยอมให้ผู้ดูแลเห็นว่าฉันกินยาแล้วหรือยัง และเป็นผู้ตั้งค่ายาให้ฉัน</div>' +
        '<button class="btn green" data-act="consent">ยินยอม</button>';
    } else {
      body += '<div class="card ok">✓ ยินยอมแล้ว — รอผู้ดูแลสแกนหรือใส่รหัส</div>';
    }
    body += '<button class="btn ghost compact" data-act="newcode">สร้างรหัสใหม่</button>';
    return cover('FR-01 · BR-01, BR-02') + '<div class="screen" data-scroll="senior">' + body + '</div>';
  }

  function dosesHtml(meal) {
    return meal.doses.map(function (d) {
      return '<div class="card">' +
        '<p class="drugname">' + esc(d.name) + '</p>' +
        '<div><strong>' + esc(d.pills) + ' เม็ด</strong></div>' +
        (d.caution ? '<div>⚠ ข้อควรระวัง: ' + esc(d.caution) + '</div>' : '') +
        (d.contraindication ? '<div>⛔ ข้อห้ามใช้: ' + esc(d.contraindication) + '</div>' : '') +
        '</div>';
    }).join('');
  }

  function seniorReminder(meals) {
    var multi = meals.length > 1;
    var body = '<h1>🔔 ถึงเวลากินยา</h1><p class="muted">เสียงเตือนดัง (จำลอง)</p>';
    meals.forEach(function (meal) {
      var round = R.currentRound(meal, S.now);
      var roundText = round >= 1 && round <= 3 ? 'เตือนครั้งที่ ' + round + ' จาก 3' : 'เลยเวลาเตือนแล้ว';
      body +=
        '<h2>' + (multi ? 'มื้อ ' : 'มื้อ ') + esc(meal.label) + ' น.</h2>' +
        '<div class="muted small">' + roundText + '</div>' +
        dosesHtml(meal) +
        '<button class="btn green" data-act="confirm" data-meal="' + esc(meal.id) + '">กินแล้ว</button>' +
        '<button class="btn red" data-act="notyet" data-meal="' + esc(meal.id) + '">ยังไม่กิน</button>';
    });
    return cover('FR-03, FR-04 · BR-08–BR-11, BR-16') + '<div class="screen" data-scroll="senior">' + body + '</div>';
  }

  function seniorHome(meals) {
    var rows = C.seniorHome(S.confirmState, meals, S.now);
    var body = '<h1>วันนี้</h1><div class="card ok">✓ เชื่อมต่อกับผู้ดูแลแล้ว</div>';
    if (!rows.length) {
      body += '<div class="card"><strong>' + esc(C.EMPTY_DAY_MESSAGE) + '</strong><div class="muted">ให้ลูกหลานเพิ่มยาจากมือถือของเขา</div></div>';
    }
    rows.forEach(function (row) {
      var m = row.meal;
      var st = row.status;
      var cls = { confirmed: 'confirmed', confirmed_late: 'late', unconfirmed: 'unconfirmed', waiting: 'waiting', reminding: 'reminding' }[st.code];
      body +=
        '<div class="card">' +
        '<div class="row"><span class="time">' + esc(m.label) + '</span><span class="badge ' + cls + '">' + esc(st.label) + (st.time ? ' ' + esc(st.time) : '') + '</span></div>' +
        '<div class="muted">' + m.doses.map(function (d) { return esc(d.name) + ' ' + esc(d.pills) + ' เม็ด'; }).join('<br>') + '</div>' +
        (row.showConfirmButton ? '<button class="btn green" data-act="confirm" data-meal="' + esc(m.id) + '">กินแล้ว (ยืนยันช้า)</button>' : '') +
        '</div>';
    });
    body += '<button class="linkbtn" data-act="askcancel" data-who="senior">ยกเลิกการเชื่อมต่อกับผู้ดูแล</button>';
    return cover('FR-04 · BR-10, BR-12, BR-15 (หน้าแรกของ Senior)') + '<div class="screen" data-scroll="senior">' + body + '</div>';
  }

  function cancelDialog(who) {
    return '<div class="overlay"><div class="dialog" role="alertdialog" aria-modal="true">' +
      '<h2>ยกเลิกการเชื่อมต่อ?</h2>' +
      '<p>ผู้ดูแลจะดูข้อมูลไม่ได้ทันที และ<strong>ข้อมูลยากับประวัติการกินยาของคู่นี้จะถูกลบ</strong></p>' +
      '<button class="btn red" data-act="cancel-yes" data-who="' + who + '">ยืนยันยกเลิก</button>' +
      '<button class="btn ghost" data-act="cancel-no">ไม่ยกเลิก</button>' +
      '</div></div>';
  }

  function renderSenior() {
    var meals = getMeals();
    var html;
    if (!P.isPaired(S.ps)) {
      html = seniorPairing();
    } else {
      var open = S.reminderIds
        .map(function (id) { return byId(meals, id); })
        .filter(function (m) { return m && !R.isConfirmed(S.confirmState, m); });
      html = open.length ? seniorReminder(open) : seniorHome(meals);
    }
    if (S.dialog === 'senior') html += cancelDialog('senior');
    document.getElementById('senior').innerHTML = html;
  }

  /* ====================== หน้าจอ Caregiver ====================== */

  function cgUnpaired() {
    var body =
      '<h1>เชื่อมต่อกับผู้สูงอายุ</h1>' +
      '<p class="muted">สแกน QR บนมือถือของผู้สูงอายุ หรือพิมพ์รหัส 6 หลัก · ผู้สูงอายุต้องกด "ยินยอม" ก่อน</p>' +
      '<button class="btn blue" data-act="scanqr">📷 สแกน QR (จำลอง)</button>' +
      '<p class="muted" style="text-align:center;margin:10px 0 0">หรือ</p>' +
      '<label class="fld">รหัสเชิญ 6 หลัก' +
      '<input id="codeInput" data-code inputmode="numeric" maxlength="6" autocomplete="off" value="' + esc(S.cg.codeInput) + '"></label>' +
      '<button class="btn green" data-act="pair">เชื่อมต่อ</button>';
    if (S.cg.pairError) body += '<div class="card alert" role="alert"><strong>เชื่อมต่อไม่ได้</strong><br>' + esc(S.cg.pairError) + '</div>';
    return cover('FR-01 · BR-01, BR-02') + '<div class="screen" data-scroll="cg">' + body + '</div>';
  }

  function statusIcon(code) {
    return { confirmed: 'confirmed', confirmed_late: 'late', unconfirmed: 'unconfirmed', waiting: 'waiting', reminding: 'reminding' }[code];
  }

  function cgStatus(meals) {
    var rows = C.dailyStatus(S.confirmState, meals, S.now);
    var body = '<h1>สถานะวันนี้</h1>';
    if (S.notifications.length) {
      body += '<h2>การแจ้งเตือน</h2>';
      S.notifications.forEach(function (n) {
        body += '<div class="card ' + (n.kind === 'unconfirmed' ? 'alert' : 'ok') + '" role="alert">' +
          '<strong>' + esc(fmt(n.at)) + '</strong> · ' + esc(n.text) + '</div>';
      });
    }
    body += '<h2>ทุกมื้อของวัน</h2>';
    if (!rows.length) {
      body += '<div class="card"><strong>' + esc(C.EMPTY_DAY_MESSAGE) + '</strong></div>';
    }
    rows.forEach(function (row) {
      var m = row.meal;
      var st = row.status;
      body +=
        '<div class="card"><div class="row"><span class="time">' + esc(m.label) + '</span>' +
        '<span class="badge ' + statusIcon(st.code) + '">' + esc(st.label) + (st.time ? ' ' + esc(st.time) : '') + '</span></div>' +
        '<div class="muted">' + m.doses.map(function (d) { return esc(d.name); }).join(', ') + '</div></div>';
    });
    body += '<p class="muted small">"กินแล้ว" คือผู้สูงอายุกดรายงานเอง ไม่ใช่หลักฐานว่ากินยาจริง</p>';
    return cover('FR-05 · BR-13, BR-14') + '<div class="screen" data-scroll="cg">' + body + '</div>';
  }

  function cgMeds() {
    var add = S.cg.add;
    if (add && add.step === 'pick') return cgAddPick();
    if (add && add.step === 'draft') return cgAddDraft(add);
    var body = '<h1>ยาของผู้สูงอายุ</h1>';
    if (S.settings) {
      body += '<div class="card muted small">เวลามื้อ: เช้า ' + esc(S.settings.morning) + ' · กลางวัน ' + esc(S.settings.noon) + ' · เย็น ' + esc(S.settings.evening) + ' · เข้านอน ' + esc(S.settings.bedtime) + '</div>';
    }
    if (!S.meds.length) body += '<div class="card"><strong>ยังไม่มียา</strong><div class="muted">กดปุ่มด้านล่างเพื่อถ่ายรูปฉลากยา</div></div>';
    S.meds.forEach(function (d) {
      var rt = S.settings ? R.reminderTime(d, S.settings) : null;
      body += '<div class="card"><p class="drugname">' + esc(d.name) + '</p>' +
        '<div>' + esc(d.pills) + ' เม็ด · ' + esc(L.describeTiming(d.timing)) + '</div>' +
        '<div><strong>เตือนเวลา ' + (rt === null ? '—' : esc(fmt(rt))) + ' น.</strong></div>' +
        (d.caution ? '<div class="muted">ข้อควรระวัง: ' + esc(d.caution) + '</div>' : '') +
        (d.contraindication ? '<div class="muted">ข้อห้ามใช้: ' + esc(d.contraindication) + '</div>' : '') + '</div>';
    });
    body += '<button class="btn blue" data-act="addstart">📷 เพิ่มยาจากฉลาก</button>';
    return cover('FR-02 · BR-03–BR-07') + '<div class="screen" data-scroll="cg">' + body + '</div>';
  }

  function cgAddPick() {
    var body = '<h1>ถ่ายรูปฉลากยา (จำลอง)</h1>' +
      '<p class="muted">ของจริงจะเปิดกล้อง · ตอนนี้เลือกตัวอย่างฉลากเพื่อดูว่าระบบอ่านแล้วเป็นอย่างไร</p>';
    MOCK.samples.forEach(function (s) {
      body += '<button class="btn ghost compact" data-act="scan" data-sample="' + esc(s.id) + '">' + esc(s.title) +
        '<div class="muted" style="font-size:16px;font-weight:400">' + esc(s.hint) + '</div></button>';
    });
    body += '<button class="btn ghost compact" data-act="manual">ไม่สแกน — กรอกข้อมูลยาเอง</button>' +
      '<button class="linkbtn" data-act="canceldraft">ยกเลิก</button>';
    return cover('FR-02 · BR-03, BR-04') + '<div class="screen" data-scroll="cg">' + body + '</div>';
  }

  function fieldHtml(label, name, value, opts) {
    opts = opts || {};
    var flagged = !!(opts.flag);
    var hidden = !(flagged && (value === '' || value == null));
    return '<label class="fld">' + esc(label) + ' <em class="flag" data-flag="' + name + '"' + (hidden ? ' hidden' : '') + '>กรุณาตรวจสอบ</em>' +
      '<input data-field="' + name + '" type="' + (opts.type || 'text') + '"' + (opts.min ? ' min="' + opts.min + '"' : '') +
      ' value="' + esc(value) + '"></label>';
  }

  function selectHtml(label, name, value, options, flag) {
    var opt = '<option value=""' + (value === '' ? ' selected' : '') + '>— เลือก —</option>' + options.map(function (o) {
      return '<option value="' + o[0] + '"' + (value === o[0] ? ' selected' : '') + '>' + esc(o[1]) + '</option>';
    }).join('');
    var hidden = !(flag && value === '');
    return '<label class="fld">' + esc(label) + ' <em class="flag" data-flag="' + name + '"' + (hidden ? ' hidden' : '') + '>กรุณาตรวจสอบ</em>' +
      '<select data-field="' + name + '">' + opt + '</select></label>';
  }

  function cgAddDraft(add) {
    var d = add.draft;
    var body = '<h1>ตรวจร่างข้อมูลยา</h1>';
    if (add.note) body += '<div class="card warn" role="alert">' + esc(add.note) + '</div>';
    if (d.unsupported) {
      body += '<div class="card alert" role="alert"><strong>' + esc(L.UNSUPPORTED_MESSAGES[d.unsupported]) + '</strong><br>จึงไม่สร้างตารางเตือนให้</div>' +
        '<button class="btn ghost" data-act="canceldraft">กลับ</button>';
      return cover('FR-02 ✗4 · BR-07') + '<div class="screen" data-scroll="cg">' + body + '</div>';
    }
    body += '<p class="muted">ร่างนี้ยังไม่ถูกบันทึก — ตรวจและแก้ได้ แล้วกด "บันทึก"</p>' +
      fieldHtml('ชื่อยา', 'name', d.name, { flag: d.flags.name }) +
      fieldHtml('จำนวนเม็ดต่อครั้ง', 'pills', d.pills, { type: 'number', min: '1', flag: d.flags.pills }) +
      selectHtml('เวลากินตามฉลาก', 'relation', d.relation, [['after', 'หลังอาหาร'], ['before', 'ก่อนอาหาร'], ['bedtime', 'ก่อนนอน']], d.flags.relation);
    if (d.relation && d.relation !== 'bedtime') {
      body += selectHtml('มื้อ', 'slot', d.slot, [['morning', 'เช้า'], ['noon', 'กลางวัน'], ['evening', 'เย็น']], d.flags.slot);
    }
    if (d.relation === 'before') {
      body += fieldHtml('ก่อนอาหารกี่นาที', 'minutesBefore', d.minutesBefore, { type: 'number', min: '1', flag: d.flags.minutesBefore });
    }
    body += fieldHtml('ข้อควรระวัง (ถ้าฉลากมี)', 'caution', d.caution) +
      fieldHtml('ข้อห้ามใช้ (ถ้าฉลากมี)', 'contraindication', d.contraindication);
    if (add.times) {
      body += '<h2>ตั้งเวลามื้อ (ครั้งแรก)</h2><p class="muted">ใช้คำนวณเวลาเตือนตามฉลาก</p><div class="two">' +
        timeField('เช้า', 'morning', add.times.morning) + timeField('กลางวัน', 'noon', add.times.noon) +
        timeField('เย็น', 'evening', add.times.evening) + timeField('เข้านอน', 'bedtime', add.times.bedtime) + '</div>';
    }
    body += '<div class="card" id="draftPreview" aria-live="polite"></div>' +
      '<div class="card alert" id="draftMsg" role="alert" hidden></div>' +
      '<button class="btn green" id="saveBtn" data-act="savedraft">บันทึก</button>' +
      '<button class="btn ghost" data-act="canceldraft">ยกเลิก (ไม่บันทึกอะไร)</button>';
    return cover('FR-02 · BR-03–BR-06 (ตรวจก่อนบันทึก)') + '<div class="screen" data-scroll="cg">' + body + '</div>';
  }

  function timeField(label, key, value) {
    return '<label class="fld">' + esc(label) + '<input type="time" data-time="' + key + '" value="' + esc(value) + '"></label>';
  }

  function cgSettings() {
    var body = '<h1>การเชื่อมต่อ</h1>' +
      '<div class="card ok">✓ เชื่อมต่อกับผู้สูงอายุแล้ว</div>' +
      '<p class="muted">ถ้ายกเลิก ข้อมูลยาและประวัติการกินยาของคู่นี้จะถูกลบ (สิทธิ์ลบข้อมูลตาม PDPA)</p>' +
      '<button class="btn red" data-act="askcancel" data-who="caregiver">ยกเลิกการจับคู่</button>';
    return cover('FR-01 · BR-17 (ยกเลิกการจับคู่)') + '<div class="screen" data-scroll="cg">' + body + '</div>';
  }

  function renderCaregiver() {
    var html;
    var meals = getMeals();
    if (!P.canView(S.ps, CG_ID, SENIOR_ID)) {
      html = cgUnpaired();
    } else {
      var tab = S.cg.tab;
      var screen;
      if (tab === 'meds') screen = cgMeds();
      else if (tab === 'settings') screen = cgSettings();
      else {
        screen = cgStatus(meals);
        S.cg.seen = S.notifications.length;
      }
      var unseen = S.notifications.length - S.cg.seen;
      html = screen + '<nav class="tabs" aria-label="เมนูผู้ดูแล">' +
        tabBtn('status', 'สถานะ', tab, unseen > 0 ? unseen : 0) + tabBtn('meds', 'ยา', tab, 0) + tabBtn('settings', 'เชื่อมต่อ', tab, 0) + '</nav>';
    }
    if (S.dialog === 'caregiver') html += cancelDialog('caregiver');
    document.getElementById('caregiver').innerHTML = html;
    refreshDraftHints();
  }

  function tabBtn(name, label, current, badge) {
    return '<button class="tab" data-act="tab" data-tab="' + name + '"' + (current === name ? ' aria-current="page"' : '') + '>' +
      label + (badge ? '<span class="dot">' + badge + '</span>' : '') + '</button>';
  }

  /** อัปเดตปุ่มบันทึก / ป้าย "กรุณาตรวจสอบ" / ตัวอย่างเวลาเตือน โดยไม่วาดฟอร์มใหม่ (กันเคอร์เซอร์หลุด) */
  function refreshDraftHints() {
    var add = S.cg.add;
    if (!add || add.step !== 'draft' || add.draft.unsupported) return;
    var d = add.draft;
    var v = L.validate(d);
    var timesOk = S.settings ? true : L.validateMealTimes(add.times).ok;
    var save = document.getElementById('saveBtn');
    if (save) save.disabled = !(v.ok && timesOk);
    document.querySelectorAll('#caregiver [data-flag]').forEach(function (el) {
      var name = el.getAttribute('data-flag');
      var empty = d[name] === '' || d[name] == null;
      el.hidden = !(d.flags[name] && empty);
    });
    var msg = document.getElementById('draftMsg');
    if (msg) {
      if (v.unsupported) {
        msg.hidden = false;
        msg.textContent = L.UNSUPPORTED_MESSAGES[v.unsupported];
      } else {
        msg.hidden = true;
      }
    }
    var prev = document.getElementById('draftPreview');
    if (prev) {
      var settings = S.settings || (timesOk ? add.times : null);
      if (v.ok && settings) {
        var rt = R.reminderTime(L.toDose(d, 'preview'), settings);
        prev.textContent = 'จะเตือนเวลา ' + (rt === null ? '—' : fmt(rt)) + ' น. (' + L.describeTiming(L.toDose(d, 'p').timing) + ')';
      } else {
        var need = [];
        if (!v.ok) need.push('กรอกช่องบังคับให้ครบ (ชื่อยา, จำนวนเม็ด, เวลากิน)');
        if (!timesOk) need.push('ตั้งเวลามื้อให้ครบ');
        prev.textContent = 'ยังบันทึกไม่ได้: ' + need.join(' · ');
      }
    }
  }

  /* ====================== วาดทั้งหมด ====================== */

  function render() {
    var scrolls = {};
    document.querySelectorAll('[data-scroll]').forEach(function (el) { scrolls[el.getAttribute('data-scroll')] = el.scrollTop; });
    renderSim();
    renderSenior();
    renderCaregiver();
    renderLog();
    document.querySelectorAll('[data-scroll]').forEach(function (el) {
      var k = el.getAttribute('data-scroll');
      if (scrolls[k]) el.scrollTop = scrolls[k];
    });
  }

  /* ====================== การกระทำ ====================== */

  function loadScenario(name) {
    var sc = MOCK.scenarios[name];
    S = fresh(sc ? sc.startTime : '06:00');
    if (sc) {
      P.giveConsent(S.ps);
      P.tryPair(S.ps, S.ps.code, CG_ID, S.now);
      S.settings = JSON.parse(JSON.stringify(sc.settings));
      S.meds = JSON.parse(JSON.stringify(sc.meds));
      doseSeq = S.meds.length;
      S.cg.seen = 0;
      addLog('โหลดชุดข้อมูล: ' + sc.title);
    } else {
      addLog('เริ่มใหม่ — ยังไม่ได้จับคู่');
    }
  }

  function startDraft(draft, note) {
    S.cg.add = { step: 'draft', draft: draft, note: note || null, times: S.settings ? null : JSON.parse(JSON.stringify(MOCK.defaultMealTimes)) };
  }

  function doPair(code, who) {
    var r = P.tryPair(S.ps, code, who, S.now);
    if (r.ok) {
      S.cg.pairError = '';
      S.cg.codeInput = '';
      addLog('จับคู่สำเร็จ (' + who + ')');
      toast('เชื่อมต่อแล้วทั้งสองเครื่อง');
    } else {
      if (who === CG_ID) S.cg.pairError = r.message;
      addLog('จับคู่ไม่สำเร็จ (' + who + '): ' + r.message);
      toast((who === CG2_ID ? 'ผู้ดูแลคนที่ 2: ' : '') + r.message, true);
    }
  }

  var actions = {
    step: function (el) { advanceTo(S.now + Number(el.getAttribute('data-n'))); },
    next: function () {
      var n = nextEventTime();
      if (n === null) toast('ไม่มีเหตุการณ์ถัดไปแล้ว', true);
      else advanceTo(n);
    },
    goto: function () {
      var v = document.getElementById('gotoTime').value;
      if (!v) return toast('กรุณาเลือกเวลา', true);
      var target = t(v);
      if (target <= S.now) return toast('เดินเวลาย้อนกลับไม่ได้ — กด "เริ่มใหม่" เพื่อกลับไป 06:00', true);
      S.gotoValue = '';
      advanceTo(target);
    },
    scenario: function (el) { loadScenario(el.getAttribute('data-name')); },
    cg2: function () { doPair(S.ps.code, CG2_ID); },
    mute: function (el) { S.mute = !!el.checked; },

    // Senior — FR-01
    consent: function () { P.giveConsent(S.ps); addLog('Senior กดยินยอม'); },
    newcode: function () { P.generateCode(S.ps, S.now); addLog('Senior สร้างรหัสใหม่'); },
    askcancel: function (el) { S.dialog = el.getAttribute('data-who'); },
    'cancel-no': function () { S.dialog = null; },
    'cancel-yes': function (el) {
      var who = el.getAttribute('data-who');
      var r = P.cancel(S.ps, true, S.now);
      S.dialog = null;
      if (r.ok) {
        S.meds = []; S.settings = null; S.confirmState = {}; S.notifications = []; S.reminderIds = [];
        S.cg.tab = 'status'; S.cg.add = null; S.cg.seen = 0; S.cg.pairError = '';
        addLog('ยกเลิกการจับคู่โดย ' + (who === 'senior' ? 'Senior' : 'Caregiver') + ' · ลบข้อมูลยาและประวัติ · สร้าง QR ใหม่');
        toast('ยกเลิกแล้ว ข้อมูลของคู่นี้ถูกลบ');
      }
    },

    // Senior — FR-03/04
    confirm: function (el) {
      var meals = getMeals();
      var meal = byId(meals, el.getAttribute('data-meal'));
      if (!meal) return;
      var r = C.confirmMeal(S.confirmState, meal, meals, S.now);
      if (!r.ok) return toast('ยืนยันไม่ได้ (' + (r.reason === 'window_closed' ? 'เลยเวลาเตือนมื้อถัดไปแล้ว' : 'ยังไม่ถึงเวลา') + ')', true);
      S.reminderIds = S.reminderIds.filter(function (id) { return id !== meal.id; });
      handleEvents(r.events);
      addLog('Senior กด "กินแล้ว" มื้อ ' + meal.label + (r.duplicate ? ' (ซ้ำ — ไม่บันทึกซ้ำ)' : r.late ? ' (ยืนยันช้า)' : ''));
      toast(r.late ? 'บันทึก: กินแล้ว (ยืนยันช้า)' : 'บันทึกแล้ว: กินแล้ว ' + fmt(S.now));
    },
    notyet: function (el) {
      var meals = getMeals();
      var meal = byId(meals, el.getAttribute('data-meal'));
      if (!meal) return;
      var r = C.pressNotYet(S.confirmState, meal, meals, S.now);
      S.reminderIds = S.reminderIds.filter(function (id) { return id !== meal.id; });
      if (!r.ok) return addLog('Senior กด "ยังไม่กิน" มื้อ ' + meal.label + ' (พ้นรอบเตือนแล้ว)');
      if (r.action === 'wait_next_round') {
        addLog('Senior กด "ยังไม่กิน" มื้อ ' + meal.label + ' → เตือนอีกครั้ง ' + fmt(r.nextAt));
        toast('จะเตือนอีกครั้งเวลา ' + fmt(r.nextAt) + ' น.');
      } else {
        addLog('Senior กด "ยังไม่กิน" รอบสุดท้าย มื้อ ' + meal.label + ' → แจ้ง Caregiver ทันที');
        handleEvents(r.events);
        toast('แจ้งผู้ดูแลแล้ว');
      }
    },

    // Caregiver — FR-01
    pair: function () { doPair(S.cg.codeInput, CG_ID); },
    scanqr: function () { doPair(S.ps.code, CG_ID); },
    tab: function (el) { S.cg.tab = el.getAttribute('data-tab'); S.cg.add = null; },

    // Caregiver — FR-02
    addstart: function () { S.cg.add = { step: 'pick' }; },
    scan: function (el) {
      var sample = byId(MOCK.samples, el.getAttribute('data-sample'));
      var r = L.draftFromOcr(sample.ocr);
      addLog('สแกนฉลาก (จำลอง): ' + sample.title);
      startDraft(r.draft, r.ok ? null : 'สแกนล้มเหลว — กรุณากรอกข้อมูลยาเอง');
    },
    manual: function () { startDraft(L.manualDraft(), null); },
    canceldraft: function () { S.cg.add = null; },
    savedraft: function () {
      var add = S.cg.add;
      if (!S.settings) {
        var tv = L.validateMealTimes(add.times);
        if (!tv.ok) return toast('ตั้งเวลามื้อให้ครบก่อน', true);
      }
      var r = L.saveDraft(S.meds, add.draft, { actor: 'caregiver', confirmed: true, id: 'd' + (++doseSeq) });
      if (!r.ok) return toast('บันทึกไม่ได้: ' + (r.reason === 'unsupported' ? L.UNSUPPORTED_MESSAGES[r.unsupported] : 'ช่องบังคับยังไม่ครบ'), true);
      if (!S.settings) S.settings = JSON.parse(JSON.stringify(add.times));
      addLog('Caregiver บันทึกยา: ' + r.dose.name + ' (' + L.describeTiming(r.dose.timing) + ')');
      S.cg.add = null;
      toast('บันทึกยาแล้ว');
    }
  };

  document.addEventListener('click', function (ev) {
    var el = ev.target.closest('[data-act]');
    if (!el || el.disabled) return;
    var name = el.getAttribute('data-act');
    if (el.tagName === 'INPUT' && el.type === 'checkbox') return; // จัดการใน change
    if (!actions[name]) return;
    actions[name](el);
    render();
  });

  document.addEventListener('change', function (ev) {
    var el = ev.target;
    if (el.matches('[data-act="mute"]')) { actions.mute(el); return; }
    if (el.matches('select[data-field]')) {
      S.cg.add.draft[el.getAttribute('data-field')] = el.value;
      if (el.getAttribute('data-field') === 'relation' && el.value === 'bedtime') S.cg.add.draft.slot = '';
      render(); // เปลี่ยนชนิดเวลา → ช่องมื้อ/นาทีเปลี่ยน
    }
  });

  document.addEventListener('input', function (ev) {
    var el = ev.target;
    if (el.matches('input[data-field]')) {
      S.cg.add.draft[el.getAttribute('data-field')] = el.value;
      refreshDraftHints();
    } else if (el.matches('input[data-time]')) {
      S.cg.add.times[el.getAttribute('data-time')] = el.value;
      refreshDraftHints();
    } else if (el.matches('input[data-code]')) {
      S.cg.codeInput = el.value;
    } else if (el.matches('[data-field-goto]')) {
      S.gotoValue = el.value;
    }
  });

  document.addEventListener('keydown', function (ev) {
    if (ev.key === 'Enter' && ev.target.matches('input[data-code]')) {
      ev.preventDefault();
      actions.pair();
      render();
    }
  });

  // ให้เทสต์/ผู้ใช้ตรวจสถานะได้จาก DevTools: MedMindApp.state()
  window.MedMindApp = { state: function () { return S; }, advanceTo: function (m) { advanceTo(m); render(); } };

  loadScenario('empty');
  render();
})();

/*
 * label.js — ตรรกะร่างข้อมูลยาจากฉลาก (OCR จำลอง) → ตรวจ → บันทึก (ไม่แตะ DOM)
 *
 * Covers: FR-02  ·  BR-03, BR-04, BR-05, BR-06, BR-07  ·  NFR-06
 *
 * รูปแบบผลอ่านฉลาก (ocr): { name, pills, relation, slot, minutesBefore, caution, contraindication, prn, failed }
 *   relation: 'after' | 'before' | 'bedtime'   ·   slot: 'morning' | 'noon' | 'evening'
 *   ค่าที่อ่านไม่ได้ = null/undefined → ช่องว่าง + "กรุณาตรวจสอบ" (BR-04 ห้ามเดา)
 */
(function (root, factory) {
  var api = factory();
  if (typeof module === 'object' && module.exports) {
    module.exports = api;
  } else {
    root.MedMind = root.MedMind || {};
    root.MedMind.label = api;
  }
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var SLOT_NAMES = Object.freeze({ morning: 'เช้า', noon: 'กลางวัน', evening: 'เย็น' });
  var RELATIONS = Object.freeze({ after: 'หลังอาหาร', before: 'ก่อนอาหาร', bedtime: 'ก่อนนอน' });
  var UNSUPPORTED_MESSAGES = Object.freeze({
    prn: 'ระบบยังไม่รองรับยาเมื่อมีอาการ', // FR-02 ✗4
    half: 'ระบบยังไม่รองรับยาครึ่งเม็ด', // BR-07
    liquid: 'ระบบยังไม่รองรับยาน้ำ' // BR-07
  });

  function blank(v) {
    return v === null || v === undefined || String(v).trim() === '';
  }

  function toNumber(v) {
    return blank(v) ? NaN : Number(v);
  }

  function isPositiveInt(v) {
    var n = toNumber(v);
    return Number.isInteger(n) && n > 0;
  }

  function emptyDraft() {
    return {
      name: '',
      pills: '',
      relation: '',
      slot: '',
      minutesBefore: '',
      caution: '',
      contraindication: '',
      unsupported: null,
      flags: {} // ช่องที่อ่านไม่ได้ตอนสแกน → UI แสดง "กรุณาตรวจสอบ" จนกว่าจะกรอก
    };
  }

  /**
   * FR-02 ✓1, ✗3, ✗4, ✗5, ✗10 — แปลงผลอ่านฉลากเป็น "ร่าง" (ยังไม่บันทึกอะไร)
   * สแกนล้มเหลว → ร่างว่างให้กรอกเอง (ok = false, reason = 'scan_failed')
   */
  function draftFromOcr(ocr) {
    if (!ocr || ocr.failed) return { ok: false, reason: 'scan_failed', draft: emptyDraft() };
    var d = emptyDraft();
    ['name', 'pills', 'relation', 'slot', 'minutesBefore', 'caution', 'contraindication'].forEach(function (k) {
      if (!blank(ocr[k])) d[k] = ocr[k];
    });
    if (d.relation === 'bedtime') d.slot = ''; // ก่อนนอนไม่มีมื้อ
    if (ocr.prn) d.unsupported = 'prn';
    if (ocr.liquid) d.unsupported = 'liquid';
    if (blank(d.name)) d.flags.name = true;
    if (blank(d.pills)) d.flags.pills = true;
    if (blank(d.relation)) d.flags.relation = true;
    if (d.relation !== 'bedtime' && blank(d.slot)) d.flags.slot = true;
    if (d.relation === 'before' && blank(d.minutesBefore)) d.flags.minutesBefore = true;
    return { ok: true, draft: d };
  }

  /** ฉลากที่ Caregiver กรอกเองทั้งหมด */
  function manualDraft() {
    return emptyDraft();
  }

  /**
   * BR-05: ช่องบังคับ = ชื่อยา, จำนวนเม็ดต่อครั้ง, มื้อ/เวลา (ข้อควรระวัง/ข้อห้ามใช้ บันทึกเฉพาะเมื่อฉลากมี)
   * BR-07: ไม่รองรับยาเมื่อมีอาการ / ยาน้ำ / ยาครึ่งเม็ด
   * คืน { ok, missing[], unsupported }
   */
  function validate(draft) {
    var unsupported = draft.unsupported || null;
    if (!unsupported && !blank(draft.pills) && Number.isFinite(toNumber(draft.pills)) && !Number.isInteger(toNumber(draft.pills))) {
      unsupported = 'half';
    }
    var missing = [];
    if (blank(draft.name)) missing.push('name');
    if (!isPositiveInt(draft.pills)) missing.push('pills');
    if (!RELATIONS[draft.relation]) {
      missing.push('relation');
    } else {
      if (draft.relation !== 'bedtime' && !SLOT_NAMES[draft.slot]) missing.push('slot');
      if (draft.relation === 'before' && !isPositiveInt(draft.minutesBefore)) missing.push('minutesBefore');
    }
    return { ok: !unsupported && missing.length === 0, missing: missing, unsupported: unsupported };
  }

  /** ร่างที่ผ่านการตรวจ → ข้อมูลยา (รูปแบบที่ reminder.js ใช้) */
  function toDose(draft, id) {
    var timing;
    if (draft.relation === 'bedtime') {
      timing = { type: 'bedtime' };
    } else if (draft.relation === 'before') {
      timing = { type: 'before', slot: draft.slot, minutesBefore: Number(draft.minutesBefore) };
    } else {
      timing = { type: 'after', slot: draft.slot };
    }
    return {
      id: id,
      name: String(draft.name).trim(),
      pills: Number(draft.pills),
      caution: blank(draft.caution) ? '' : String(draft.caution).trim(),
      contraindication: blank(draft.contraindication) ? '' : String(draft.contraindication).trim(),
      timing: timing
    };
  }

  /**
   * BR-03 + BR-04 + NFR-06: เพิ่มยาได้เฉพาะ Caregiver และต้องกดยืนยันทุกครั้ง
   * opts = { actor: 'caregiver', confirmed: true, id }
   * ค่าที่บันทึกคือค่าที่ Caregiver แก้ในร่าง (FR-02 ✓2) · ไม่ผ่านการตรวจ = ไม่บันทึกอะไรเลย
   */
  function saveDraft(list, draft, opts) {
    opts = opts || {};
    if (opts.actor !== 'caregiver') return { ok: false, reason: 'caregiver_only' };
    if (opts.confirmed !== true) return { ok: false, reason: 'not_confirmed' };
    var v = validate(draft);
    if (v.unsupported) return { ok: false, reason: 'unsupported', unsupported: v.unsupported, missing: v.missing };
    if (!v.ok) return { ok: false, reason: 'missing_fields', missing: v.missing };
    var dose = toDose(draft, opts.id);
    list.push(dose);
    return { ok: true, dose: dose };
  }

  /** BR-06: Caregiver ตั้งเวลามื้อเช้า/กลางวัน/เย็น + เวลาเข้านอน ครั้งแรกตอนเพิ่มยา */
  function validateMealTimes(times) {
    var missing = [];
    ['morning', 'noon', 'evening', 'bedtime'].forEach(function (k) {
      var m = /^(\d{1,2}):(\d{2})$/.exec(times && times[k] ? String(times[k]) : '');
      if (!m || Number(m[1]) > 23 || Number(m[2]) > 59) missing.push(k);
    });
    return { ok: missing.length === 0, missing: missing };
  }

  /** ข้อความอธิบายเวลาเตือนตามฉลาก เช่น "ก่อนอาหารเช้า 30 นาที" */
  function describeTiming(timing) {
    if (!timing) return '';
    if (timing.type === 'bedtime') return 'ก่อนนอน';
    var base = RELATIONS[timing.type === 'before' ? 'before' : 'after'] + SLOT_NAMES[timing.slot];
    return timing.type === 'before' ? base + ' ' + timing.minutesBefore + ' นาที' : base;
  }

  return {
    SLOT_NAMES: SLOT_NAMES,
    RELATIONS: RELATIONS,
    UNSUPPORTED_MESSAGES: UNSUPPORTED_MESSAGES,
    emptyDraft: emptyDraft,
    manualDraft: manualDraft,
    draftFromOcr: draftFromOcr,
    validate: validate,
    toDose: toDose,
    saveDraft: saveDraft,
    validateMealTimes: validateMealTimes,
    describeTiming: describeTiming
  };
});

/*
 * pairing.js — ตรรกะจับคู่ Senior–Caregiver (ไม่แตะ DOM)
 *
 * Covers: FR-01  ·  BR-01, BR-02, BR-17  ·  NFR-04, NFR-05, NFR-10
 *
 * เวลา (now) เป็นนาทีนับจากเที่ยงคืน เหมือน reminder.js · rand ใส่เองได้เพื่อให้เทสต์ได้ค่าคงที่
 */
(function (root, factory) {
  var api = factory();
  if (typeof module === 'object' && module.exports) {
    module.exports = api;
  } else {
    root.MedMind = root.MedMind || {};
    root.MedMind.pairing = api;
  }
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  /** BR-01: รหัสหมดอายุใน 10 นาที — เกิน 10 นาที (> 10) ถือว่าหมดอายุ ตามถ้อยคำ FR-01 ✗4 */
  var CODE_TTL_MINUTES = 10;

  var MESSAGES = Object.freeze({
    no_consent: 'รอผู้สูงอายุกดยินยอมก่อน จึงจะเชื่อมต่อได้',
    invalid_code: 'รหัสไม่ถูกต้อง กรุณาตรวจสอบรหัส 6 หลักอีกครั้ง',
    expired: 'รหัสหมดอายุแล้ว (เกิน 10 นาที) ให้ผู้สูงอายุกด "สร้างรหัสใหม่"',
    used: 'รหัสนี้ถูกใช้ไปแล้ว ให้ผู้สูงอายุกด "สร้างรหัสใหม่"',
    already_paired: 'ผู้สูงอายุท่านนี้มีผู้ดูแลแล้ว',
    need_confirm: 'ต้องกดยืนยันอีกครั้งก่อนยกเลิกการจับคู่',
    not_paired: 'ยังไม่ได้จับคู่'
  });

  function fail(reason) {
    return { ok: false, reason: reason, message: MESSAGES[reason] };
  }

  function randomCode(rand) {
    var r = rand || Math.random;
    var n = Math.floor(r() * 1000000);
    return ('000000' + n).slice(-6);
  }

  /** สร้างรหัสใหม่ (BR-01: กด "สร้างรหัสใหม่" ได้) — รหัสเดิมถูกเก็บไว้เพื่อแยก "ใช้แล้ว" ออกจาก "ผิด" */
  function generateCode(ps, now, rand) {
    if (ps.code !== null) ps.retired.push({ code: ps.code, used: ps.codeUsed });
    var code = randomCode(rand);
    var guard = 0;
    while (code === ps.code && guard++ < 5) code = randomCode(rand);
    ps.code = code;
    ps.codeCreatedAt = now;
    ps.codeUsed = false;
    return code;
  }

  function create(seniorId, now, rand) {
    var ps = {
      seniorId: seniorId,
      consent: false,
      caregiverId: null,
      code: null,
      codeCreatedAt: null,
      codeUsed: false,
      retired: []
    };
    generateCode(ps, now, rand);
    return ps;
  }

  /** BR-02: Senior ต้องกดยินยอมก่อนเชื่อมต่อ (Senior ไม่มีบัญชี/รหัสผ่าน) */
  function giveConsent(ps) {
    ps.consent = true;
    return ps;
  }

  function isPaired(ps) {
    return ps.caregiverId !== null;
  }

  /** นาทีที่เหลือของรหัสปัจจุบัน (แสดงบนหน้า Senior) */
  function codeMinutesLeft(ps, now) {
    return Math.max(0, CODE_TTL_MINUTES - (now - ps.codeCreatedAt));
  }

  /**
   * FR-01 ✗2, ✓3, ✗4, ✗5 — Caregiver สแกน/ใส่รหัส
   * ลำดับตรวจ: มีผู้ดูแลแล้ว → ยังไม่ยินยอม → รหัส (ถูก/หมดอายุ/ใช้แล้ว/ผิด)
   * NFR-05: ไม่มีการเชื่อมต่อก่อน Senior ยินยอม (0 ครั้ง)
   */
  function tryPair(ps, code, caregiverId, now) {
    if (isPaired(ps)) return fail('already_paired'); // BR-02: Senior 1 คน มี Caregiver ได้ 1 คน
    if (!ps.consent) return fail('no_consent');
    var input = String(code == null ? '' : code).replace(/\s+/g, '');
    if (input === ps.code) {
      if (now - ps.codeCreatedAt > CODE_TTL_MINUTES) return fail('expired');
      ps.caregiverId = caregiverId;
      ps.codeUsed = true; // BR-01: ใช้ได้ 1 ครั้ง
      return { ok: true };
    }
    var old = ps.retired.filter(function (r) { return r.code === input; })[0];
    if (old && old.used) return fail('used');
    return fail('invalid_code');
  }

  /**
   * BR-17: ยกเลิกการจับคู่ — Senior หรือ Caregiver กดได้ ต้องยืนยันอีกครั้ง
   * → Caregiver หมดสิทธิ์ดูข้อมูลทันที · deleteData = true (ผู้เรียกต้องลบข้อมูลยา + ประวัติของคู่นี้)
   * → Senior เห็น QR/รหัสใหม่ (และต้องยินยอมใหม่ก่อนจับคู่ครั้งต่อไป)
   */
  function cancel(ps, confirmed, now, rand) {
    if (!confirmed) return fail('need_confirm');
    if (!isPaired(ps)) return fail('not_paired');
    ps.caregiverId = null;
    ps.consent = false;
    generateCode(ps, now, rand);
    return { ok: true, deleteData: true, newCode: ps.code };
  }

  /** NFR-04 / NFR-10: Caregiver เห็นเฉพาะข้อมูลของ Senior ที่จับคู่อยู่ในขณะนี้ */
  function canView(ps, caregiverId, seniorId) {
    if (!isPaired(ps) || ps.caregiverId !== caregiverId) return false;
    if (seniorId !== undefined && seniorId !== ps.seniorId) return false;
    return true;
  }

  return {
    CODE_TTL_MINUTES: CODE_TTL_MINUTES,
    MESSAGES: MESSAGES,
    create: create,
    generateCode: generateCode,
    giveConsent: giveConsent,
    isPaired: isPaired,
    codeMinutesLeft: codeMinutesLeft,
    tryPair: tryPair,
    cancel: cancel,
    canView: canView
  };
});

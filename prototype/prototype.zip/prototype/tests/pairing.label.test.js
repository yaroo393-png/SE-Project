/*
 * เทสต์ของ pairing.js (FR-01 AC 1–6, NFR-04/05/10) และ label.js (FR-02 AC 1–10, NFR-06)
 * รัน: cd prototype && node --test
 */
'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const pairing = require('../js/logic/pairing.js');
const label = require('../js/logic/label.js');
const reminder = require('../js/logic/reminder.js');

const t = reminder.parseTime;
const fixed = (digits) => () => Number(digits) / 1000000; // rand คงที่ → รหัส digits
const SETTINGS = { morning: '07:00', noon: '12:00', evening: '18:00', bedtime: '21:00' };

function newPairing() {
  return pairing.create('s1', t('06:00'), fixed('123456'));
}

// ---------- FR-01 ----------
test('FR-01 ✓1: Senior เปิดแอปครั้งแรก → มีรหัส 6 หลักให้ ไม่ต้องสมัครบัญชี', () => {
  const ps = newPairing();
  assert.match(ps.code, /^\d{6}$/);
  assert.equal(pairing.isPaired(ps), false);
});

test('FR-01 ✗2 / NFR-05: Senior ยังไม่ยินยอม → จับคู่ไม่ได้ และแจ้งว่ารอการยินยอม', () => {
  const ps = newPairing();
  const r = pairing.tryPair(ps, ps.code, 'cg1', t('06:01'));
  assert.equal(r.ok, false);
  assert.equal(r.reason, 'no_consent');
  assert.match(r.message, /ยินยอม/);
  assert.equal(pairing.isPaired(ps), false);
});

test('FR-01 ✓3: Senior ยินยอมแล้ว + รหัสถูกต้อง → เชื่อมต่อแล้ว', () => {
  const ps = newPairing();
  pairing.giveConsent(ps);
  const r = pairing.tryPair(ps, '123 456', 'cg1', t('06:05')); // เว้นวรรคได้
  assert.equal(r.ok, true);
  assert.equal(pairing.isPaired(ps), true);
});

test('FR-01 ✗4: รหัสผิด / เกิน 10 นาที / ถูกใช้แล้ว → ปฏิเสธพร้อมข้อความชัดเจน ไม่เชื่อมต่อ', () => {
  const ps = newPairing();
  pairing.giveConsent(ps);
  assert.equal(pairing.tryPair(ps, '000000', 'cg1', t('06:01')).reason, 'invalid_code');
  assert.equal(pairing.tryPair(ps, ps.code, 'cg1', t('06:10')).ok, true); // ครบ 10 นาทีพอดียังใช้ได้
  const ps2 = newPairing();
  pairing.giveConsent(ps2);
  const late = pairing.tryPair(ps2, ps2.code, 'cg1', t('06:11')); // เกิน 10 นาที
  assert.equal(late.reason, 'expired');
  assert.match(late.message, /หมดอายุ/);
  assert.equal(pairing.isPaired(ps2), false);
});

test('BR-01: รหัสใช้ได้ 1 ครั้ง — หลังยกเลิกจับคู่ รหัสเดิมถูกปฏิเสธว่า "ใช้แล้ว"', () => {
  const ps = newPairing();
  pairing.giveConsent(ps);
  const oldCode = ps.code;
  pairing.tryPair(ps, oldCode, 'cg1', t('06:02'));
  pairing.cancel(ps, true, t('06:03'), fixed('654321'));
  pairing.giveConsent(ps);
  const r = pairing.tryPair(ps, oldCode, 'cg1', t('06:04'));
  assert.equal(r.reason, 'used');
  assert.equal(pairing.tryPair(ps, '654321', 'cg1', t('06:04')).ok, true);
});

test('BR-01: Senior กด "สร้างรหัสใหม่" → รหัสเก่าใช้ไม่ได้ รหัสใหม่เริ่มนับ 10 นาทีใหม่', () => {
  const ps = newPairing();
  pairing.giveConsent(ps);
  pairing.generateCode(ps, t('06:08'), fixed('777777'));
  assert.equal(pairing.tryPair(ps, '123456', 'cg1', t('06:09')).reason, 'invalid_code');
  assert.equal(pairing.tryPair(ps, '777777', 'cg1', t('06:18')).ok, true);
  assert.equal(pairing.codeMinutesLeft(ps, t('06:12')), 6);
});

test('FR-01 ✗5 / BR-02: Senior จับคู่แล้ว → Caregiver คนที่ 2 ถูกปฏิเสธ "ผู้สูงอายุท่านนี้มีผู้ดูแลแล้ว"', () => {
  const ps = newPairing();
  pairing.giveConsent(ps);
  pairing.tryPair(ps, ps.code, 'cg1', t('06:01'));
  const r = pairing.tryPair(ps, ps.code, 'cg2', t('06:02'));
  assert.equal(r.ok, false);
  assert.equal(r.message, 'ผู้สูงอายุท่านนี้มีผู้ดูแลแล้ว');
  assert.equal(ps.caregiverId, 'cg1');
});

test('FR-01 ✗6 / BR-17 / NFR-10: ยกเลิกต้องยืนยัน → Caregiver ดูข้อมูลไม่ได้ทันที · สั่งลบข้อมูล · Senior ได้ QR ใหม่', () => {
  const ps = newPairing();
  pairing.giveConsent(ps);
  pairing.tryPair(ps, ps.code, 'cg1', t('06:01'));
  assert.equal(pairing.canView(ps, 'cg1', 's1'), true);

  const noConfirm = pairing.cancel(ps, false, t('06:05'));
  assert.equal(noConfirm.ok, false);
  assert.equal(pairing.canView(ps, 'cg1', 's1'), true); // ยังไม่ยืนยัน = ยังดูได้

  const r = pairing.cancel(ps, true, t('06:06'), fixed('222222'));
  assert.equal(r.ok, true);
  assert.equal(r.deleteData, true);
  assert.equal(r.newCode, '222222');
  assert.equal(ps.code, '222222');
  assert.equal(ps.consent, false);
  assert.equal(pairing.canView(ps, 'cg1', 's1'), false); // NFR-10: ขอดูข้อมูลสำเร็จ 0 ครั้ง
});

test('NFR-04: Caregiver ขอข้อมูลของ Senior คนอื่น → ถูกปฏิเสธ', () => {
  const ps = newPairing();
  pairing.giveConsent(ps);
  pairing.tryPair(ps, ps.code, 'cg1', t('06:01'));
  assert.equal(pairing.canView(ps, 'cg1', 'other-senior'), false);
  assert.equal(pairing.canView(ps, 'cg2', 's1'), false);
});

// ---------- FR-02 ----------
const CLEAR = { name: 'ยาตัวอย่าง A', pills: 1, relation: 'after', slot: 'morning', caution: 'ดื่มน้ำตาม', contraindication: 'ห้ามใช้ถ้าแพ้ยา' };

test('FR-02 ✓1: รูปฉลากชัด → ร่างครบทุกช่อง และยังไม่บันทึกอะไร', () => {
  const list = [];
  const r = label.draftFromOcr(CLEAR);
  assert.equal(r.ok, true);
  assert.equal(r.draft.name, 'ยาตัวอย่าง A');
  assert.deepEqual(r.draft.flags, {});
  assert.equal(label.validate(r.draft).ok, true);
  assert.equal(list.length, 0);
});

test('FR-02 ✓2 / BR-04: Caregiver แก้ช่องในร่าง → ค่าที่บันทึกคือค่าที่แก้', () => {
  const list = [];
  const { draft } = label.draftFromOcr(CLEAR);
  draft.pills = '2';
  const res = label.saveDraft(list, draft, { actor: 'caregiver', confirmed: true, id: 'd1' });
  assert.equal(res.ok, true);
  assert.equal(list[0].pills, 2);
});

test('FR-02 ✗3 / BR-04, BR-05: ช่องอ่านไม่ได้ = ว่าง + "กรุณาตรวจสอบ" (ไม่เดา) และบันทึกไม่ได้จนช่องบังคับครบ', () => {
  const list = [];
  const { draft } = label.draftFromOcr({ ...CLEAR, name: null, pills: null });
  assert.equal(draft.name, '');
  assert.equal(draft.flags.name, true);
  assert.equal(draft.flags.pills, true);
  const res = label.saveDraft(list, draft, { actor: 'caregiver', confirmed: true, id: 'd1' });
  assert.equal(res.ok, false);
  assert.deepEqual(res.missing, ['name', 'pills']);
  assert.equal(list.length, 0);
});

test('FR-02 ✗4 / BR-07: ฉลากยาเมื่อมีอาการ → แจ้ง "ระบบยังไม่รองรับยาเมื่อมีอาการ" และบันทึกไม่ได้', () => {
  const list = [];
  const { draft } = label.draftFromOcr({ ...CLEAR, prn: true });
  const v = label.validate(draft);
  assert.equal(v.unsupported, 'prn');
  assert.equal(label.UNSUPPORTED_MESSAGES.prn, 'ระบบยังไม่รองรับยาเมื่อมีอาการ');
  assert.equal(label.saveDraft(list, draft, { actor: 'caregiver', confirmed: true }).ok, false);
  assert.equal(list.length, 0);
});

test('BR-07: ยาครึ่งเม็ดไม่รองรับ', () => {
  const { draft } = label.draftFromOcr(CLEAR);
  draft.pills = '0.5';
  assert.equal(label.validate(draft).unsupported, 'half');
});

test('FR-02 ✗5: สแกนล้มเหลว → เปิดฟอร์มว่างให้กรอกเอง', () => {
  const r = label.draftFromOcr({ failed: true });
  assert.equal(r.ok, false);
  assert.equal(r.reason, 'scan_failed');
  assert.equal(r.draft.name, '');
});

test('FR-02 ✗7: ยกเลิกในหน้าร่าง → ไม่บันทึกอะไร (ไม่เรียก saveDraft = ลิสต์ว่าง)', () => {
  const list = [];
  label.draftFromOcr(CLEAR);
  assert.equal(list.length, 0);
});

test('BR-04 / NFR-06: ไม่กดยืนยันโดย Caregiver = ไม่บันทึก (0 รายการ) · BR-03: เพิ่มได้เฉพาะ Caregiver', () => {
  const list = [];
  const { draft } = label.draftFromOcr(CLEAR);
  assert.equal(label.saveDraft(list, draft, { actor: 'caregiver', confirmed: false }).reason, 'not_confirmed');
  assert.equal(label.saveDraft(list, draft, { actor: 'senior', confirmed: true }).reason, 'caregiver_only');
  assert.equal(list.length, 0);
});

test('FR-02 ✓6/✓8/✓9 (BR-06): ฉลากบันทึกแล้วได้เวลาเตือนตามฉลาก 07:00 / 06:30 / 21:00', () => {
  const cases = [
    [{ ...CLEAR, relation: 'after', slot: 'morning' }, '07:00'],
    [{ ...CLEAR, relation: 'before', slot: 'morning', minutesBefore: 30 }, '06:30'],
    [{ ...CLEAR, relation: 'bedtime', slot: null }, '21:00']
  ];
  for (const [ocr, expected] of cases) {
    const list = [];
    const { draft } = label.draftFromOcr(ocr);
    const res = label.saveDraft(list, draft, { actor: 'caregiver', confirmed: true, id: 'x' });
    assert.equal(res.ok, true);
    assert.equal(reminder.formatTime(reminder.reminderTime(res.dose, SETTINGS)), expected);
  }
});

test('FR-02 ✗10: ฉลาก "ก่อนอาหาร" ไม่ระบุนาที → ช่องนาทีว่าง + กรุณาตรวจสอบ บันทึกไม่ได้จนกรอก', () => {
  const list = [];
  const { draft } = label.draftFromOcr({ ...CLEAR, relation: 'before', slot: 'evening', minutesBefore: null });
  assert.equal(draft.minutesBefore, '');
  assert.equal(draft.flags.minutesBefore, true);
  assert.deepEqual(label.validate(draft).missing, ['minutesBefore']);
  assert.equal(label.saveDraft(list, draft, { actor: 'caregiver', confirmed: true }).ok, false);
  draft.minutesBefore = '20';
  assert.equal(label.saveDraft(list, draft, { actor: 'caregiver', confirmed: true, id: 'y' }).ok, true);
});

test('BR-05: ข้อควรระวัง/ข้อห้ามใช้ ไม่บังคับ (บันทึกเฉพาะเมื่อฉลากมี)', () => {
  const { draft } = label.draftFromOcr({ ...CLEAR, caution: null, contraindication: null });
  assert.equal(label.validate(draft).ok, true);
  assert.equal(label.toDose(draft, 'z').caution, '');
});

test('BR-06: ตั้งเวลามื้อครั้งแรกต้องครบ 4 ค่า (เช้า/กลางวัน/เย็น/เข้านอน)', () => {
  assert.equal(label.validateMealTimes(SETTINGS).ok, true);
  assert.deepEqual(label.validateMealTimes({ morning: '07:00' }).missing, ['noon', 'evening', 'bedtime']);
  assert.equal(label.validateMealTimes({ ...SETTINGS, noon: '25:00' }).ok, false);
});

test('describeTiming: ข้อความเวลาเตือนตามฉลาก', () => {
  assert.equal(label.describeTiming({ type: 'after', slot: 'morning' }), 'หลังอาหารเช้า');
  assert.equal(label.describeTiming({ type: 'before', slot: 'morning', minutesBefore: 30 }), 'ก่อนอาหารเช้า 30 นาที');
  assert.equal(label.describeTiming({ type: 'bedtime' }), 'ก่อนนอน');
});
